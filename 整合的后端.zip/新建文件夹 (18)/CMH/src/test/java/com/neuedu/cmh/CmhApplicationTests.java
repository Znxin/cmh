package com.neuedu.cmh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmhApplicationTests {

    @Test
    void contextLoads() {
    }

}
