package com.example.mystuent.mapper;

import com.example.mystuent.entity.Dormitory;
import com.example.mystuent.entity.Stu;
import com.example.mystuent.entity.StudentDormitory;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface DormitoryMapper {
    @Select("SELECT * FROM dormitory")
    List<Dormitory> getAll();

    @Select("<script>" +
            "SELECT * FROM dormitory " +
            "<where>" +
            "   <if test='dormId != null'> AND dorm_id = #{dormId}</if>" +
            "   <if test='building != null and building != \"\"'> AND building LIKE CONCAT('%', #{building}, '%')</if>" +
            "   <if test='roomNumber != null and roomNumber != \"\"'> AND room_number LIKE CONCAT('%', #{roomNumber}, '%')</if>" +
            "   <if test='description != null and description != \"\"'> AND description LIKE CONCAT('%', #{description}, '%')</if>" +
            "</where>" +
            "LIMIT #{offset}, #{pageSize}" +
            "</script>")
    List<Dormitory> searchDormitory(@Param("dormId") Integer dormId,
                                    @Param("building") String building,
                                    @Param("roomNumber") String roomNumber,
                                    @Param("description") String description,
                                    @Param("offset") int offset,
                                    @Param("pageSize") int pageSize);

    @Select("<script>" +
            "SELECT COUNT(*) FROM dormitory " +
            "<where>" +
            "   <if test='dormId != null'> AND dorm_id = #{dormId}</if>" +
            "   <if test='building != null and building != \"\"'> AND building LIKE CONCAT('%', #{building}, '%')</if>" +
            "   <if test='roomNumber != null and roomNumber != \"\"'> AND room_number LIKE CONCAT('%', #{roomNumber}, '%')</if>" +
            "   <if test='description != null and description != \"\"'> AND description LIKE CONCAT('%', #{description}, '%')</if>" +
            "</where>" +
            "</script>")
    int countDormitory(@Param("dormId") Integer dormId,
                       @Param("building") String building,
                       @Param("roomNumber") String roomNumber,
                       @Param("description") String description);

    @Insert("INSERT INTO dormitory VALUES(null, #{dormName}, #{building}, #{roomNumber}, #{capacity}, #{currentCount}, #{description})")
    int addDormitory(Dormitory dormitory);

    @Update("UPDATE dormitory SET dorm_name=#{dormName}, building=#{building}, room_number=#{roomNumber}, " +
            "capacity=#{capacity}, current_count=#{currentCount}, description=#{description} WHERE dorm_id=#{dormId}")
    int updateDormitory(Dormitory dormitory);

    @Delete("DELETE FROM dormitory WHERE dorm_id=#{dormId}")
    int deleteDormitory(int dormId);

    @Select("SELECT * FROM dormitory WHERE dorm_id=#{dormId}")
    Dormitory getById(int dormId);

    // 在 DormitoryMapper.java 中添加
    @Insert("INSERT INTO student_dormitory VALUES(null, #{stuno}, #{dormId}, NOW())")
    int assignStudentToDormitory(StudentDormitory studentDormitory);

    @Delete("DELETE FROM student_dormitory WHERE stuno=#{stuno}")
    int removeStudentFromDormitory(int stuno);

    @Select("SELECT d.* FROM dormitory d JOIN student_dormitory sd ON d.dorm_id = sd.dorm_id WHERE sd.stuno=#{stuno}")
    Dormitory findDormitoryByStuno(int stuno);

    @Select("SELECT s.* FROM stu s JOIN student_dormitory sd ON s.stuno = sd.stuno WHERE sd.dorm_id=#{dormId}")
    List<Stu> findStudentsByDormitory(int dormId);

    @Update("UPDATE dormitory SET current_num = current_num + 1 WHERE dorm_id=#{dormId} AND current_num < capacity")
    int increaseDormitoryCurrentNum(int dormId);

    @Update("UPDATE dormitory SET current_num = current_num - 1 WHERE dorm_id=#{dormId} AND current_num > 0")
    int decreaseDormitoryCurrentNum(int dormId);
}