package com.example.mystuent.entity;

public class StuPageQuery extends StuQuery {
    private int pageNum;
    private int pageSize;

    // getters and setters
    public int getPageNum() {
        return pageNum;
    }
    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }
    public int getPageSize() {
        return pageSize;
    }
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}