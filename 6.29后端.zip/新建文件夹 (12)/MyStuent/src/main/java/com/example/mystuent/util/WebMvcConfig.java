package com.example.mystuent.util;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Value("${sd.output.dir}")
    private String sdOutputDir;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // 原有上传文件路径映射
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:uploads/");

        // 新增Stable Diffusion输出目录映射
        registry.addResourceHandler("/sd-output/**")
                .addResourceLocations("file:" + sdOutputDir + "/");

        // 如果你也想映射media目录（根据你的DOCX文档）
        registry.addResourceHandler("/media/**")
                .addResourceLocations("classpath:/media/");
    }
}