package com.example.mystuent.entity;

public class Score {
    private int scoreId;
    private int stuno;
    private String courseName;
    private double score;
    private String semester;
    private int credit;

    public Score(int scoreId, int stuno, String courseName, double score, String semester, int credit) {
        this.scoreId = scoreId;
        this.stuno = stuno;
        this.courseName = courseName;
        this.score = score;
        this.semester = semester;
        this.credit = credit;

    }

    // 添加学生姓名字段(用于前端显示)
    private String stuname;

    public Score(int i, int i1, String math, String spring, double v) {
    }

    // getters and setters
    public int getScoreId() { return scoreId; }
    public void setScoreId(int scoreId) { this.scoreId = scoreId; }
    public int getStuno() { return stuno; }

    public Score() {
    }

    public void setStuno(int stuno) { this.stuno = stuno; }
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public double getScore() { return score; }
    public void setScore(double score) { this.score = score; }
    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }
    public int getCredit() { return credit; }
    public void setCredit(int credit) { this.credit = credit; }
    public String getStuname() { return stuname; }
    public void setStuname(String stuname) { this.stuname = stuname; }
}