package com.example.mystuent.entity;

import java.util.Date;

public class StudentDormitory {
    private int id;
    private int stuno;
    private int dormId;
    private Date checkInDate;

    // getters and setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getStuno() {
        return stuno;
    }
    public void setStuno(int stuno) {
        this.stuno = stuno;
    }
    public int getDormId() {
        return dormId;
    }
    public void setDormId(int dormId) {
        this.dormId = dormId;
    }
    public Date getCheckInDate() {
        return checkInDate;
    }
    public void setCheckInDate(Date checkInDate) {
        this.checkInDate = checkInDate;
    }
}