package com.example.mystuent.mapper;

import com.example.mystuent.entity.Score;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface ScoreMapper {
    @Select("SELECT s.score_id, s.stuno, st.stuname, s.course_name, s.score, s.semester, s.credit " +
            "FROM score s LEFT JOIN stu st ON s.stuno = st.stuno " +
            "WHERE s.score_id > 0 " +
            "ORDER BY s.score_id DESC LIMIT #{offset}, #{pageSize}")
    List<Score> getAllWithPage(@Param("offset") int offset, @Param("pageSize") int pageSize);

    @Select("SELECT COUNT(*) FROM score s LEFT JOIN stu st ON s.stuno = st.stuno")
    int countAll();

    @Insert("INSERT INTO score(score_id, stuno, course_name, score, semester, credit) " +
            "VALUES(#{scoreId}, #{stuno}, #{courseName}, #{score}, #{semester}, #{credit})")
// 移除@Options注解，因为我们不再使用自增ID
    int addScore(Score score);
    @Update("UPDATE score SET " +
            "stuno = #{stuno}, " +
            "course_name = #{courseName}, " +
            "score = #{score}, " +
            "semester = #{semester}, " +
            "credit = #{credit} " +
            "WHERE score_id = #{scoreId}")
    int updateScore(Score score);

    @Delete("DELETE FROM score WHERE score_id = #{scoreId}")
    int deleteScore(@Param("scoreId") int scoreId);

    @Select("SELECT s.*, st.stuname FROM score s LEFT JOIN stu st ON s.stuno = st.stuno WHERE s.score_id = #{scoreId}")
    Score getById(@Param("scoreId") int scoreId);

    @Select("<script>" +
            "SELECT s.score_id, s.stuno, st.stuname, s.course_name, s.score, s.semester, s.credit " +
            "FROM score s LEFT JOIN stu st ON s.stuno = st.stuno " +
            "WHERE 1=1 " +
            "<if test='stuno != null'> AND s.stuno = #{stuno} </if>" +
            "<if test='courseId != null'> AND CAST(s.score_id AS CHAR) LIKE CONCAT('%', #{courseId}, '%') </if>" +
            "<if test='courseName != null and courseName != \"\"'> AND s.course_name LIKE CONCAT('%', #{courseName}, '%') </if>" +
            "<if test='semester != null and semester != \"\"'> AND s.semester LIKE CONCAT('%', #{semester}, '%') </if>" +
            "<if test='minScore != null'> AND s.score &gt;= #{minScore} </if>" +
            "<if test='maxScore != null'> AND s.score &lt;= #{maxScore} </if>" +
            "ORDER BY s.score_id DESC LIMIT #{offset}, #{pageSize}" +
            "</script>")
    List<Score> searchScores(@Param("stuno") Integer stuno,
                             @Param("courseId") Integer courseId,
                             @Param("courseName") String courseName,
                             @Param("semester") String semester,
                             @Param("minScore") Double minScore,
                             @Param("maxScore") Double maxScore,
                             @Param("offset") int offset,
                             @Param("pageSize") int pageSize);

    @Select("<script>" +
            "SELECT COUNT(*) FROM score s LEFT JOIN stu st ON s.stuno = st.stuno " +
            "WHERE 1=1 " +
            "<if test='stuno != null'> AND s.stuno = #{stuno} </if>" +
            "<if test='courseId != null'> AND CAST(s.score_id AS CHAR) LIKE CONCAT('%', #{courseId}, '%') </if>" +
            "<if test='courseName != null and courseName != \"\"'> AND s.course_name LIKE CONCAT('%', #{courseName}, '%') </if>" +
            "<if test='semester != null and semester != \"\"'> AND s.semester LIKE CONCAT('%', #{semester}, '%') </if>" +
            "<if test='minScore != null'> AND s.score &gt;= #{minScore} </if>" +
            "<if test='maxScore != null'> AND s.score &lt;= #{maxScore} </if>" +
            "</script>")
    int countSearchResults(@Param("stuno") Integer stuno,
                           @Param("courseId") Integer courseId,
                           @Param("courseName") String courseName,
                           @Param("semester") String semester,
                           @Param("minScore") Double minScore,
                           @Param("maxScore") Double maxScore);

    @Select("SELECT AVG(score) FROM score")
    Double getAverageScore();

    @Select("SELECT COUNT(*) FROM score WHERE score &lt; 60")
    int getFailCount();

    @Select("<script>" +
            "SELECT " +
            "SUM(CASE WHEN score &gt;= 90 THEN 1 ELSE 0 END) AS excellent, " +
            "SUM(CASE WHEN score &gt;= 80 AND score &lt; 90 THEN 1 ELSE 0 END) AS good, " +
            "SUM(CASE WHEN score &gt;= 70 AND score &lt; 80 THEN 1 ELSE 0 END) AS medium, " +
            "SUM(CASE WHEN score &gt;= 60 AND score &lt; 70 THEN 1 ELSE 0 END) AS pass, " +
            "SUM(CASE WHEN score &lt; 60 THEN 1 ELSE 0 END) AS fail " +
            "FROM score" +
            "</script>")
    Map<String, Integer> getScoreDistribution();

    @Select("<script>" +
            "SELECT " +
            "AVG(score) AS averageScore, " +
            "COUNT(CASE WHEN score &lt; 60 THEN 1 END) AS failCount, " +
            "COUNT(*) AS totalCount, " +
            "SUM(CASE WHEN score &gt;= 90 THEN 1 ELSE 0 END) AS excellent, " +
            "SUM(CASE WHEN score &gt;= 80 AND score &lt; 90 THEN 1 ELSE 0 END) AS good, " +
            "SUM(CASE WHEN score &gt;= 70 AND score &lt; 80 THEN 1 ELSE 0 END) AS medium, " +
            "SUM(CASE WHEN score &gt;= 60 AND score &lt; 70 THEN 1 ELSE 0 END) AS pass " +
            "FROM score WHERE stuno = #{stuno}" +
            "</script>")
    Map<String, Object> getStudentAnalysis(@Param("stuno") int stuno);

    @Select("<script>" +
            "SELECT " +
            "AVG(score) AS averageScore, " +
            "COUNT(CASE WHEN score &lt; 60 THEN 1 END) AS failCount, " +
            "COUNT(*) AS totalCount, " +
            "SUM(CASE WHEN score &gt;= 90 THEN 1 ELSE 0 END) AS excellent, " +
            "SUM(CASE WHEN score &gt;= 80 AND score &lt; 90 THEN 1 ELSE 0 END) AS good, " +
            "SUM(CASE WHEN score &gt;= 70 AND score &lt; 80 THEN 1 ELSE 0 END) AS medium, " +
            "SUM(CASE WHEN score &gt;= 60 AND score &lt; 70 THEN 1 ELSE 0 END) AS pass " +
            "FROM score WHERE score_id = #{courseId}" +  // 修改为score_id
            "</script>")
    Map<String, Object> getCourseAnalysis(@Param("courseId") int courseId);

    @Select("<script>" +
            "SELECT " +
            "AVG(score) AS averageScore, " +
            "COUNT(CASE WHEN score &lt; 60 THEN 1 END) AS failCount, " +
            "COUNT(*) AS totalCount " +
            "FROM score WHERE 1=1 " +
            "<if test='stuno != null'> AND stuno = #{stuno} </if>" +
            "<if test='courseId != null'> AND score_id = #{courseId} </if>" +  // 使用score_id
            "</script>")
    Map<String, Object> getBasicAnalysis(@Param("stuno") Integer stuno, @Param("courseId") Integer courseId);
}