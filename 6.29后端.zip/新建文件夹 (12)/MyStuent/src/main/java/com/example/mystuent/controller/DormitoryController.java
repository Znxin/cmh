package com.example.mystuent.controller;

import com.example.mystuent.entity.Dormitory;
import com.example.mystuent.entity.Stu;
import com.example.mystuent.mapper.DormitoryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.mystuent.entity.StudentDormitory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/dormitory")
public class DormitoryController {
    @Autowired
    private DormitoryMapper dormitoryMapper;

    @GetMapping("/all")
    public List<Dormitory> getAll() {
        return dormitoryMapper.getAll();
    }

    @GetMapping("/search")
    public Map<String, Object> searchDormitory(
            @RequestParam(required = false) Integer dormId,
            @RequestParam(required = false) String building,
            @RequestParam(required = false) String roomNumber,
            @RequestParam(required = false) String description,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize) {

        int offset = (page - 1) * pageSize;
        List<Dormitory> data = dormitoryMapper.searchDormitory(dormId, building, roomNumber, description, offset, pageSize);
        int total = dormitoryMapper.countDormitory(dormId, building, roomNumber, description);

        Map<String, Object> result = new HashMap<>();
        result.put("data", data);
        result.put("total", total);
        result.put("page", page);
        result.put("pageSize", pageSize);
        return result;
    }

    @PostMapping("/add")
    public int addDormitory(@RequestBody Dormitory dormitory) {
        return dormitoryMapper.addDormitory(dormitory);
    }

    @PostMapping("/update")
    public int updateDormitory(@RequestBody Dormitory dormitory) {
        return dormitoryMapper.updateDormitory(dormitory);
    }

    @GetMapping("/delete")
    public int deleteDormitory(@RequestParam int dormId) {
        return dormitoryMapper.deleteDormitory(dormId);
    }

    @GetMapping("/get")
    public Dormitory getById(@RequestParam int dormId) {
        return dormitoryMapper.getById(dormId);
    }
    // 在 DormitoryController.java 中添加
    @PostMapping("/assign")
    public int assignStudentToDormitory(@RequestBody StudentDormitory studentDormitory) {
        try {
            // 检查学生是否已有寝室
            Dormitory existing = dormitoryMapper.findDormitoryByStuno(studentDormitory.getStuno());
            if (existing != null) {
                throw new RuntimeException("该学生已分配寝室");
            }

            // 检查寝室是否已满
            Dormitory dorm = dormitoryMapper.findDormitoryByStuno(studentDormitory.getDormId());
            if (dorm.getCurrentCount() >= dorm.getCapacity()) {
                throw new RuntimeException("该寝室已满");
            }

            // 分配寝室
            int result = dormitoryMapper.assignStudentToDormitory(studentDormitory);
            if (result > 0) {
                dormitoryMapper.increaseDormitoryCurrentNum(studentDormitory.getDormId());
            }
            return result;
        } catch (Exception e) {
            throw new RuntimeException("分配寝室失败: " + e.getMessage());
        }
    }

    @DeleteMapping("/remove/{stuno}")
    public int removeStudentFromDormitory(@PathVariable int stuno) {
        try {
            // 获取学生当前寝室
            Dormitory dorm = dormitoryMapper.findDormitoryByStuno(stuno);
            if (dorm == null) {
                throw new RuntimeException("该学生未分配寝室");
            }

            // 移除分配
            int result = dormitoryMapper.removeStudentFromDormitory(stuno);
            if (result > 0) {
                dormitoryMapper.decreaseDormitoryCurrentNum(dorm.getDormId());
            }
            return result;
        } catch (Exception e) {
            throw new RuntimeException("移除寝室分配失败: " + e.getMessage());
        }
    }

    @GetMapping("/student/{stuno}")
    public Dormitory getStudentDormitory(@PathVariable int stuno) {
        return dormitoryMapper.findDormitoryByStuno(stuno);
    }

    @GetMapping("/students/{dormId}")
    public List<Stu> getDormitoryStudents(@PathVariable int dormId) {
        return dormitoryMapper.findStudentsByDormitory(dormId);
    }

}