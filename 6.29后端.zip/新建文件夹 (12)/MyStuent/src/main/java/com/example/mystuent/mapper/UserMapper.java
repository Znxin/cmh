package com.example.mystuent.mapper;

import com.example.mystuent.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {
    @Select("select * from user where uname=#{uname} and upwd=#{upwd}")
    User Login(User user);

    @Select("select count(*) from user where uname=#{uname}")
    int checkUsernameExists(String uname);

    @Insert("insert into user(uname, upwd) values(#{uname}, #{upwd})")
    int register(User user);
}