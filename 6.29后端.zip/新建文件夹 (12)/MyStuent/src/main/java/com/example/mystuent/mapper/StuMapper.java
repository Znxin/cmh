package com.example.mystuent.mapper;

import com.example.mystuent.entity.Announcement;
import com.example.mystuent.entity.Stu;
import com.example.mystuent.entity.StuQuery;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface StuMapper {
    //查询所有学生信息
    @Select("select * from stu")
    List<Stu> getall();

    //删除某个学生
    @Delete("delete from stu where stuno=#{stuno}")
    int DelStu(int stuno);
    @Select("SELECT * FROM stu WHERE stuno = #{stuno}")
    Stu getStudentById(Integer stuno);
    //添加学生信息
    @Insert("insert into stu values(null,#{stuname},#{stusex},#{stuage},#{stuphone},#{imgpath})")
    int addstu(Stu stu);

    //修改学生信息
    @Update("update stu set stuname=#{stuname},stusex=#{stusex},stuage=#{stuage}," +
            "stuphone=#{stuphone},imgpath=#{imgpath} where stuno=#{stuno}")
    int upstu(Stu stu);

    // 组合查询方法
    @Select("<script>" +
            "select * from stu where 1=1" +
            "<if test='stuname != null and stuname != \"\"'> and stuname like concat('%', #{stuname}, '%')</if>" +
            "<if test='stusex != null and stusex != \"\"'> and stusex = #{stusex}</if>" +
            "<if test='minAge != null'> and stuage >= #{minAge}</if>" +
            "<if test='maxAge != null'> and stuage &lt;= #{maxAge}</if>" +
            "</script>")
    List<Stu> search(StuQuery query);

    // 修改分页查询方法
    @Select("<script>" +
            "SELECT * FROM stu WHERE 1=1" +
            "<if test='stuname != null and stuname != \"\"'> AND stuname LIKE CONCAT('%', #{stuname}, '%')</if>" +
            "<if test='stusex != null and stusex != \"\"'> AND stusex = #{stusex}</if>" +
            "<if test='minAge != null'> AND stuage >= #{minAge}</if>" +
            "<if test='maxAge != null'> AND stuage &lt;= #{maxAge}</if>" +
            " LIMIT #{pageSize} OFFSET #{offset}" +
            "</script>")
    List<Stu> searchByPage(@Param("stuname") String stuname,
                           @Param("stusex") String stusex,
                           @Param("minAge") Integer minAge,
                           @Param("maxAge") Integer maxAge,
                           @Param("pageSize") int pageSize,
                           @Param("offset") int offset);

    // 添加计数方法
    @Select("<script>" +
            "select count(*) from stu where 1=1" +
            "<if test='stuname != null'> and stuname like concat('%', #{stuname}, '%')</if>" +
            "<if test='stusex != null'> and stusex = #{stusex}</if>" +
            "<if test='minAge != null'> and stuage >= #{minAge}</if>" +
            "<if test='maxAge != null'> and stuage &lt;= #{maxAge}</if>" +
            "</script>")
    int count(StuQuery query);
    // 在StuMapper接口中添加以下方法

    @Insert("INSERT INTO announcement(title, content, attachment_path, create_time) " +
            "VALUES(#{title}, #{content}, #{attachmentPath}, #{createTime})")
    int insertAnnouncement(Announcement announcement);

    @Select("SELECT * FROM announcement ORDER BY create_time DESC")
    List<Announcement> getAllAnnouncements();
    @Delete("DELETE FROM announcement WHERE id = #{id}")
    int deleteAnnouncement(Integer id);

}
