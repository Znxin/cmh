package com.example.mystuent.entity;

public class CoursePageQuery extends CourseQuery {
    private int pageNum ;
    private int pageSize ;

    // Getters and Setters
    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}