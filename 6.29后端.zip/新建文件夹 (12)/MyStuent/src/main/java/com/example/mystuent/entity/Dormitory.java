package com.example.mystuent.entity;

public class Dormitory {
    private int dormId;
    private String dormName;
    private String building;
    private String roomNumber;
    private int capacity;
    private int currentCount;
    private String description;

    // getters and setters
    public int getDormId() { return dormId; }
    public void setDormId(int dormId) { this.dormId = dormId; }
    public String getDormName() { return dormName; }
    public void setDormName(String dormName) { this.dormName = dormName; }
    public String getBuilding() { return building; }
    public void setBuilding(String building) { this.building = building; }
    public String getRoomNumber() { return roomNumber; }
    public void setRoomNumber(String roomNumber) { this.roomNumber = roomNumber; }
    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }
    public int getCurrentCount() { return currentCount; }
    public void setCurrentCount(int currentCount) { this.currentCount = currentCount; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
}