package com.example.mystuent.entity;

public class StuQuery {
    private String stuname;
    private String stusex;
    private Integer minAge;
    private Integer maxAge;

    // getters and setters
    public String getStuname() {
        return stuname;
    }
    public void setStuname(String stuname) {
        this.stuname = stuname;
    }
    public String getStusex() {
        return stusex;
    }
    public void setStusex(String stusex) {
        this.stusex = stusex;
    }
    public Integer getMinAge() {
        return minAge;
    }
    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }
    public Integer getMaxAge() {
        return maxAge;
    }
    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }
}