package com.example.mystuent.controller;


import com.example.mystuent.entity.Announcement;
import com.example.mystuent.entity.Stu;
import com.example.mystuent.entity.StuPageQuery;
import com.example.mystuent.entity.StuQuery;
import com.example.mystuent.mapper.StuMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
// 添加缓存相关依赖 (Spring Cache + Redis)
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.CacheEvict;

@RestController
@CrossOrigin
public class StuController {
    @Autowired
    StuMapper stuMapper;
    // 在类定义中添加
    @Configuration
    public class WebConfig implements WebMvcConfigurer {
        @Override
        public void addResourceHandlers(ResourceHandlerRegistry registry) {
            String uploadDir = System.getProperty("user.dir") + "/uploads/";
            registry.addResourceHandler("/uploads/**")
                    .addResourceLocations("file:" + uploadDir);
        }
    }

    // 查询所有
    @CacheEvict(value = {"students", "studentsPage"}, allEntries = true)
    @RequestMapping("/getall")
    public List<Stu> getall(){
        return stuMapper.getall();
    }

    // 删除学生

    // 修改删除方法，使用DELETE方法并添加路径变量

    @DeleteMapping("/delstu/{stuno}")
    public ResponseEntity<?> deleteStudent(@PathVariable Integer stuno) {
        try {
            // 先检查学生是否存在
            Stu student = stuMapper.getStudentById(stuno);
            if (student == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("找不到学号为 " + stuno + " 的学生");
            }

            // 执行删除
            int result = stuMapper.DelStu(stuno);
            if (result > 0) {
                return ResponseEntity.ok("删除成功");
            } else {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("删除失败，数据库操作未影响任何行");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("删除过程中发生错误: " + e.getMessage());
        }
    }

    // 添加学生
    @CacheEvict(value = {"students", "studentsPage"}, allEntries = true)
    @RequestMapping("/addstu")
    public int addstu(@RequestBody Stu stu){
        return stuMapper.addstu(stu);
    }

    //修改学生
    @CacheEvict(value = {"students", "studentsPage"}, allEntries = true)
    @RequestMapping("/upstu")
    public int upstu(@RequestBody Stu stu){
        return stuMapper.upstu(stu);
    }

    // 添加新的查询方法
    // 组合查询方法
    @Cacheable(value = "students", key = "#query.hashCode()")
    @RequestMapping("/search")
    public List<Stu> search(@RequestBody StuQuery query) {
        return stuMapper.search(query);
    }
    // 添加分页查询方法
    // 添加分页查询方法
    @Cacheable(value = "studentsPage", key = "#query.hashCode()")
    @RequestMapping("/searchByPage")
    public Map<String, Object> searchByPage(@RequestBody StuPageQuery query) {
        Map<String, Object> result = new HashMap<>();

        // 计算offset
        int offset = query.getPageSize() * (query.getPageNum() - 1);

        // 获取分页数据
        List<Stu> data = stuMapper.searchByPage(
                query.getStuname(),
                query.getStusex(),
                query.getMinAge(),
                query.getMaxAge(),
                query.getPageSize(),
                offset
        );

        // 关键点：确保使用相同的查询条件获取总数
        StuQuery countQuery = new StuQuery();
        countQuery.setStuname(query.getStuname());
        countQuery.setStusex(query.getStusex());
        countQuery.setMinAge(query.getMinAge());
        countQuery.setMaxAge(query.getMaxAge());

        int total = stuMapper.count(countQuery);

        // 确保total至少为0
        result.put("data", data);
        result.put("total", Math.max(total, 0));

        // 添加日志
        System.out.println("返回数据条数: " + data.size());
        System.out.println("返回总记录数: " + total);

        return result;
    }
    // 添加计数方法
    @RequestMapping("/count")
    public int count(@RequestBody StuQuery query) {
        return stuMapper.count(query);
    }
    // 添加文件上传方法
    @PostMapping("/upload")
    public Map<String, Object> upload(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            throw new RuntimeException("请选择文件");
        }

        File dest;
        try {
            // 创建上传目录
            String uploadDir = System.getProperty("user.dir") + "/uploads/";
            File dir = new File(uploadDir);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            // 生成唯一文件名并保留原始扩展名
            String originalFilename = file.getOriginalFilename();
            String fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
            String fileName = UUID.randomUUID().toString() + fileExtension;

            // 保存文件
            dest = new File(uploadDir + fileName);
            file.transferTo(dest);

            // 返回结果
            Map<String, Object> result = new HashMap<>();
            result.put("filename", fileName);
            result.put("url", "/uploads/" + fileName);
            System.out.println("文件保存路径: " + dest.getAbsolutePath());
            System.out.println("文件URL: " + "/uploads/" + fileName);
            return result;
        } catch (IOException e) {
            throw new RuntimeException("文件上传失败", e);
        }

    }
    // 在StuController类中添加以下方法

    // 发布公告
    @PostMapping("/publishAnnouncement")
    public int publishAnnouncement(@RequestBody Announcement announcement) {
        announcement.setCreateTime(new Date());
        return stuMapper.insertAnnouncement(announcement);
    }

    // 获取所有公告
    @GetMapping("/getAllAnnouncements")
    public List<Announcement> getAllAnnouncements() {
        return stuMapper.getAllAnnouncements();
    }

    // 公告文件上传
    @PostMapping("/uploadAnnouncementFile")
    public Map<String, Object> uploadAnnouncementFile(@RequestParam("file") MultipartFile file) {
        // 可以与现有的upload方法共用，或者单独处理
        return upload(file);
    }
    // 删除公告
    @RequestMapping("/deleteAnnouncement")
    public int deleteAnnouncement(@RequestParam Integer id) {
        return stuMapper.deleteAnnouncement(id);
    }
    // 添加以下方法到StuController
    @GetMapping("/download")
    public ResponseEntity<Resource> downloadFile(@RequestParam String filename) {
        try {
            // 安全校验文件名
            if (filename == null || filename.isEmpty() || filename.contains("..")) {
                throw new RuntimeException("无效的文件名");
            }

            String uploadDir = System.getProperty("user.dir") + "/uploads/";
            Path filePath = Paths.get(uploadDir).resolve(filename).normalize();

            // 检查文件是否存在
            if (!Files.exists(filePath)) {
                throw new RuntimeException("文件不存在: " + filename);
            }

            // 检查文件是否可读
            if (!Files.isReadable(filePath)) {
                throw new RuntimeException("文件无法读取: " + filename);
            }

            // 获取文件MIME类型
            String contentType = Files.probeContentType(filePath);
            if (contentType == null) {
                contentType = "application/octet-stream";
            }

            // 创建Resource对象
            Resource resource = new InputStreamResource(Files.newInputStream(filePath));

            // 获取原始文件名（从数据库查询或从其他途径）
            String originalFilename = filename;
            // 这里可以改为从数据库获取原始文件名
            System.out.println("尝试下载文件: " + filePath.toString());
            System.out.println("文件存在: " + Files.exists(filePath));
            System.out.println("文件可读: " + Files.isReadable(filePath));
            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            "attachment; filename=\"" + URLEncoder.encode(originalFilename, "UTF-8") + "\"")
                    .body(resource);
        } catch (Exception e) {
            throw new RuntimeException("文件下载失败: " + e.getMessage(), e);
        }
    }
}

