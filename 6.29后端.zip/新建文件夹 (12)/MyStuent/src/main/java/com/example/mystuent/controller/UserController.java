package com.example.mystuent.controller;

import com.example.mystuent.entity.User;
import com.example.mystuent.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin
public class UserController {
    @Autowired
    UserMapper userMapper;

    // 登录
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        User loggedInUser = userMapper.Login(user);

        if (loggedInUser != null) {
            String uname = loggedInUser.getUname().toLowerCase(); // 转换为小写方便判断
            String redirectPage = "";

            if (uname.contains("admin")) {
                redirectPage = "home";
            } else if (uname.contains("teacher")) {
                redirectPage = "home1";
            } else if (uname.contains("student")) {
                redirectPage = "home2";
            } else {
                redirectPage = "default"; // 默认页面，如果没有匹配的关键字
            }

            response.put("success", true);
            response.put("message", "登录成功");
            response.put("user", loggedInUser);
            response.put("redirectPage", redirectPage); // 添加跳转页面信息
        } else {
            response.put("success", false);
            response.put("message", "用户名或密码错误");
        }
        return ResponseEntity.ok(response);
    }

    // 注册（保持不变）
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();

        // 检查用户名是否已存在
        if (userMapper.checkUsernameExists(user.getUname()) > 0) {
            response.put("success", false);
            response.put("message", "用户名已存在");
            return ResponseEntity.ok(response);
        }

        // 注册新用户
        int result = userMapper.register(user);
        if (result > 0) {
            response.put("success", true);
            response.put("message", "注册成功");
        } else {
            response.put("success", false);
            response.put("message", "注册失败");
        }
        return ResponseEntity.ok(response);
    }
}