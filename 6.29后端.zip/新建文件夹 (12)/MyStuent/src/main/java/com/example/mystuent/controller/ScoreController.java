package com.example.mystuent.controller;

import com.example.mystuent.entity.Score;
import com.example.mystuent.mapper.ScoreMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/score")
public class ScoreController {
    @Autowired
    private ScoreMapper scoreMapper;

    @PostMapping("/list")
    public ResponseEntity<?> getScoreList(@RequestBody Map<String, Object> params) {
        try {
            System.out.println("收到分页请求，参数: " + params); // 添加日志

            Map<String, Object> result = new HashMap<>();
            int pageNum = (int) params.getOrDefault("pageNum", 1);
            int pageSize = (int) params.getOrDefault("pageSize", 10);
            int offset = (pageNum - 1) * pageSize;

            List<Score> data = scoreMapper.getAllWithPage(offset, pageSize);
            int total = scoreMapper.countAll();

            System.out.println("查询结果 - 数据量: " + data.size() + ", 总数: " + total);

            result.put("success", true);
            result.put("data", data);
            result.put("total", total);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            e.printStackTrace();
            return errorResponse(e, "获取成绩列表失败");
        }
    }
    // 添加成绩
    @PostMapping("/add")
    public ResponseEntity<?> addScore(@RequestBody Score score) {
        try {
            // 数据验证
            if (score.getStuno() <= 0 || isEmpty(score.getCourseName()) || isEmpty(score.getSemester())) {
                return badRequest("学号、课程名称和学期不能为空");
            }

            int result = scoreMapper.addScore(score);
            return successResponse(result > 0, "添加成功", result);
        } catch (Exception e) {
            return errorResponse(e, "添加失败");
        }
    }

    // 更新成绩
    @PostMapping("/update")
    public ResponseEntity<?> updateScore(@RequestBody Score score) {
        try {
            // 数据验证
            if (score.getScoreId() <= 0 || score.getStuno() <= 0 ||
                    isEmpty(score.getCourseName()) || isEmpty(score.getSemester())) {
                return badRequest("成绩ID、学号、课程名称和学期不能为空");
            }

            int result = scoreMapper.updateScore(score);
            if (result > 0) {
                return successResponse(true, "更新成功", result);
            } else {
                return successResponse(false, "未找到对应的成绩记录或数据未变更", result);
            }
        } catch (Exception e) {
            return errorResponse(e, "更新失败");
        }
    }

    // 修改删除方法
    // 修改删除方法
    @PostMapping("/delete")
    public ResponseEntity<?> deleteScore(@RequestBody Map<String, Object> params) {
        try {
            System.out.println("删除请求参数: " + params);

            // 更灵活的参数处理
            Object scoreIdObj = params.get("scoreId");
            Integer scoreId = null;

            if (scoreIdObj instanceof Integer) {
                scoreId = (Integer) scoreIdObj;
            } else if (scoreIdObj instanceof String) {
                try {
                    scoreId = Integer.parseInt((String) scoreIdObj);
                } catch (NumberFormatException e) {
                    return badRequest("成绩ID必须是数字");
                }
            } else if (scoreIdObj instanceof Number) {
                scoreId = ((Number) scoreIdObj).intValue();
            }

            if (scoreId == null || scoreId <= 0) {
                return badRequest("无效的成绩ID");
            }

            System.out.println("准备删除成绩ID: " + scoreId);

            // 检查记录是否存在
            Score existing = scoreMapper.getById(scoreId);
            if (existing == null) {
                return successResponse(false, "未找到对应的成绩记录", null);
            }

            int result = scoreMapper.deleteScore(scoreId);
            System.out.println("删除操作结果: " + result);

            return successResponse(result > 0, result > 0 ? "删除成功" : "删除失败", null);
        } catch (Exception e) {
            e.printStackTrace();
            return errorResponse(e, "删除失败");
        }
    }

    // 辅助方法
    private boolean isEmpty(String str) {
        return str == null || str.trim().isEmpty();
    }

    private ResponseEntity<?> successResponse(boolean success, String message, Object data) {
        Map<String, Object> response = new HashMap<>();
        response.put("success", success);
        response.put("message", message);
        response.put("data", data);
        return ResponseEntity.ok(response);
    }

    private ResponseEntity<?> badRequest(String message) {
        return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", message
        ));
    }

    private ResponseEntity<?> errorResponse(Exception e, String message) {
        return ResponseEntity.status(500).body(Map.of(
                "success", false,
                "message", message + ": " + e.getMessage()
        ));
    }
    // 组合查询和模糊查询
    @PostMapping("/search")
    public ResponseEntity<?> searchScores(@RequestBody Map<String, Object> params) {
        try {
            System.out.println("搜索请求参数: " + params);

            // 安全获取分页参数
            int pageNum = params.get("pageNum") != null ?
                    Integer.parseInt(params.get("pageNum").toString()) : 1;
            int pageSize = params.get("pageSize") != null ?
                    Integer.parseInt(params.get("pageSize").toString()) : 10;
            int offset = (pageNum - 1) * pageSize;

            // 安全获取查询参数
            Integer stuno = null;
            if (params.get("stuno") != null && !params.get("stuno").toString().isEmpty()) {
                try {
                    stuno = Integer.parseInt(params.get("stuno").toString());
                } catch (NumberFormatException e) {
                    return badRequest("学号必须是数字");
                }
            }

            Integer courseId = null;
            if (params.get("courseId") != null && !params.get("courseId").toString().isEmpty()) {
                try {
                    courseId = Integer.parseInt(params.get("courseId").toString());
                } catch (NumberFormatException e) {
                    return badRequest("课程编号必须是数字");
                }
            }

            String courseName = params.get("courseName") != null ?
                    params.get("courseName").toString() : "";
            String semester = params.get("semester") != null ?
                    params.get("semester").toString() : "";

            Double minScore = null;
            if (params.get("minScore") != null && !params.get("minScore").toString().isEmpty()) {
                try {
                    minScore = Double.parseDouble(params.get("minScore").toString());
                } catch (NumberFormatException e) {
                    return badRequest("最低分必须是数字");
                }
            }

            Double maxScore = null;
            if (params.get("maxScore") != null && !params.get("maxScore").toString().isEmpty()) {
                try {
                    maxScore = Double.parseDouble(params.get("maxScore").toString());
                } catch (NumberFormatException e) {
                    return badRequest("最高分必须是数字");
                }
            }

            List<Score> data = scoreMapper.searchScores(stuno, courseId, courseName,
                    semester, minScore, maxScore, offset, pageSize);
            int total = scoreMapper.countSearchResults(stuno, courseId, courseName,
                    semester, minScore, maxScore);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("data", data);
            result.put("total", total);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            e.printStackTrace();
            return errorResponse(e, "查询失败");
        }
    }
    // 成绩分析
    @GetMapping("/analysis")
    public ResponseEntity<?> getScoreAnalysis() {
        try {
            Map<String, Object> analysis = new HashMap<>();

            // 平均分
            Double avgScore = scoreMapper.getAverageScore();
            analysis.put("averageScore", avgScore != null ? Math.round(avgScore * 100) / 100.0 : 0);

            // 不及格人数及占比
            int failCount = scoreMapper.getFailCount();
            int totalCount = scoreMapper.countAll();
            double failPercentage = totalCount > 0 ? Math.round((failCount * 100.0 / totalCount) * 100) / 100.0 : 0;

            analysis.put("failCount", failCount);
            analysis.put("failPercentage", failPercentage);
            analysis.put("totalCount", totalCount);

            // 成绩分布
            analysis.put("scoreDistribution", scoreMapper.getScoreDistribution());

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", analysis
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return errorResponse(e, "获取分析数据失败");
        }
    }

    // 动态成绩分析
    @PostMapping("/dynamicAnalysis")
    public ResponseEntity<?> getDynamicAnalysis(@RequestBody Map<String, Object> params) {
        try {
            Integer stuno = params.get("stuno") != null ? Integer.parseInt(params.get("stuno").toString()) : null;
            Integer courseId = params.get("courseId") != null ? Integer.parseInt(params.get("courseId").toString()) : null;

            Map<String, Object> analysis = new HashMap<>();

            // 动态查询条件
            if (stuno != null) {
                analysis.put("studentAnalysis", scoreMapper.getStudentAnalysis(stuno));
            }
            if (courseId != null) {
                analysis.put("courseAnalysis", scoreMapper.getCourseAnalysis(courseId));
            }

            // 通用分析数据
            analysis.put("basicAnalysis", scoreMapper.getBasicAnalysis(stuno, courseId));

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "data", analysis
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return errorResponse(e, "获取分析数据失败");
        }
    }
}