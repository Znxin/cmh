package com.example.mystuent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class MyStuentApplication {

    public static void main(String[] args) {
        SpringApplication.run(MyStuentApplication.class, args);
    }

}
