package com.example.mystuent;

import com.example.mystuent.controller.ScoreController;
import com.example.mystuent.entity.Score;
import com.example.mystuent.mapper.ScoreMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ScoreControllerTest {

    @Mock
    private ScoreMapper scoreMapper;

    @InjectMocks
    private ScoreController scoreController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getScoreList_Success() {
        // 准备测试数据
        Score score1 = new Score(1, 1001, "Math", "Spring", 90.5);
        Score score2 = new Score(2, 1002, "English", "Spring", 85.0);
        List<Score> mockScores = Arrays.asList(score1, score2);

        // 模拟Mapper行为
        when(scoreMapper.getAllWithPage(anyInt(), anyInt())).thenReturn(mockScores);
        when(scoreMapper.countAll()).thenReturn(2);

        // 准备请求参数
        Map<String, Object> params = new HashMap<>();
        params.put("pageNum", 1);
        params.put("pageSize", 10);

        // 执行测试
        ResponseEntity<?> response = scoreController.getScoreList(params);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertTrue((Boolean) responseBody.get("success"));

        List<Score> data = (List<Score>) responseBody.get("data");
        assertEquals(2, data.size());
        assertEquals(2, responseBody.get("total"));

        // 验证Mapper调用
        verify(scoreMapper).getAllWithPage(0, 10);
        verify(scoreMapper).countAll();
    }

    @Test
    void addScore_Success() {
        // 准备测试数据 - 确保所有必填字段都有有效值
        Score score = new Score(22,8,"web",60.00,"12",1);
        score.setStuname("张三"); // 添加学生姓名

        // 模拟Mapper行为
        when(scoreMapper.addScore(any(Score.class))).thenReturn(1);

        // 执行测试
        ResponseEntity<?> response = scoreController.addScore(score);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertTrue((Boolean) responseBody.get("success"));
        assertEquals("添加成功", responseBody.get("message"));

        // 验证Mapper调用
        verify(scoreMapper).addScore(score);
    }

    @Test
    void addScore_InvalidInput() {
        // 测试无效输入 - 学号为0
        Score score1 = new Score(0, 0, "Math", "Spring", 90.5);
        ResponseEntity<?> response1 = scoreController.addScore(score1);
        assertEquals(400, response1.getStatusCodeValue());

        // 测试无效输入 - 课程名称为空
        Score score2 = new Score(0, 1001, "", "Spring", 90.5);
        ResponseEntity<?> response2 = scoreController.addScore(score2);
        assertEquals(400, response2.getStatusCodeValue());

        // 测试无效输入 - 学期为空
        Score score3 = new Score(0, 1001, "Math", "", 90.5);
        ResponseEntity<?> response3 = scoreController.addScore(score3);
        assertEquals(400, response3.getStatusCodeValue());

        // 验证Mapper未被调用
        verify(scoreMapper, never()).addScore(any());
    }

    @Test
    void updateScore_Success() {
        // 准备测试数据 - 确保所有必填字段都有有效值
        Score score = new Score(1,6,"Math",90.00,"春",1);
        score.setStuname("张三"); // 添加学生姓名

        // 模拟Mapper行为
        when(scoreMapper.updateScore(any(Score.class))).thenReturn(1);

        // 执行测试
        ResponseEntity<?> response = scoreController.updateScore(score);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertTrue((Boolean) responseBody.get("success"));
        assertEquals("更新成功", responseBody.get("message"));

        // 验证Mapper调用
        verify(scoreMapper).updateScore(score);
    }

    @Test
    void updateScore_NotFound() {
        // 准备测试数据 - 确保所有必填字段都有有效值
        Score score = new Score(4,8,"软测",100.00,"春",2);
        score.setStuname("张三"); // 添加学生姓名

        // 模拟Mapper行为 - 返回0表示没有更新任何记录
        when(scoreMapper.updateScore(any(Score.class))).thenReturn(0);

        // 执行测试
        ResponseEntity<?> response = scoreController.updateScore(score);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertFalse((Boolean) responseBody.get("success"));
        assertEquals("未找到对应的成绩记录或数据未变更", responseBody.get("message"));

        // 验证Mapper调用
        verify(scoreMapper).updateScore(score);
    }

    @Test
    void deleteScore_Success() {
        // 准备测试数据
        Map<String, Object> params = new HashMap<>();
        params.put("scoreId", 1);

        // 模拟Mapper行为
        Score mockScore = new Score();
        mockScore.setScoreId(1);
        when(scoreMapper.getById(1)).thenReturn(mockScore);
        when(scoreMapper.deleteScore(1)).thenReturn(1);

        // 执行测试
        ResponseEntity<?> response = scoreController.deleteScore(params);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertTrue((Boolean) responseBody.get("success"));
        assertEquals("删除成功", responseBody.get("message"));

        // 验证Mapper调用
        verify(scoreMapper).getById(1);
        verify(scoreMapper).deleteScore(1);
    }

    @Test
    void deleteScore_NotFound() {
        // 准备测试数据
        Map<String, Object> params = new HashMap<>();
        params.put("scoreId", 999);

        // 模拟Mapper行为 - 记录不存在
        when(scoreMapper.getById(999)).thenReturn(null);

        // 执行测试
        ResponseEntity<?> response = scoreController.deleteScore(params);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertFalse((Boolean) responseBody.get("success"));
        assertEquals("未找到对应的成绩记录", responseBody.get("message"));

        // 验证Mapper调用
        verify(scoreMapper).getById(999);
        verify(scoreMapper, never()).deleteScore(anyInt());
    }


    @Test
    void getScoreAnalysis_Success() {
        // 模拟Mapper行为
        when(scoreMapper.getAverageScore()).thenReturn(85.5);
        when(scoreMapper.getFailCount()).thenReturn(3);
        when(scoreMapper.countAll()).thenReturn(30);

        // 修复这里 - 使用正确的返回类型
        Map<String, Integer> distribution = new HashMap<>();
        distribution.put("excellent", 10);
        distribution.put("good", 15);
        distribution.put("medium", 5);
        when(scoreMapper.getScoreDistribution()).thenReturn(distribution);

        // 执行测试
        ResponseEntity<?> response = scoreController.getScoreAnalysis();

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertTrue((Boolean) responseBody.get("success"));

        Map<String, Object> analysis = (Map<String, Object>) responseBody.get("data");
        assertEquals(85.5, analysis.get("averageScore"));
        assertEquals(3, analysis.get("failCount"));
        assertEquals(10.0, analysis.get("failPercentage"));
        assertEquals(30, analysis.get("totalCount"));
        assertNotNull(analysis.get("scoreDistribution"));
    }

    @Test
    void getDynamicAnalysis_WithStuno() {
        // 模拟Mapper行为
        Map<String, Object> studentAnalysis = new HashMap<>();
        studentAnalysis.put("studentName", "张三");
        studentAnalysis.put("averageScore", 88.5);
        studentAnalysis.put("courseCount", 5);
        when(scoreMapper.getStudentAnalysis(1001)).thenReturn(studentAnalysis);

        Map<String, Object> basicAnalysis = new HashMap<>();
        basicAnalysis.put("totalCourses", 5);
        basicAnalysis.put("averageScore", 88.5);
        basicAnalysis.put("maxScore", 95.0);
        basicAnalysis.put("minScore", 82.0);
        when(scoreMapper.getBasicAnalysis(1001, null)).thenReturn(basicAnalysis);

        // 准备请求参数
        Map<String, Object> params = new HashMap<>();
        params.put("stuno", "1001");

        // 执行测试
        ResponseEntity<?> response = scoreController.getDynamicAnalysis(params);

        // 验证结果
        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());

        Map<String, Object> responseBody = (Map<String, Object>) response.getBody();
        assertTrue((Boolean) responseBody.get("success"));

        Map<String, Object> analysis = (Map<String, Object>) responseBody.get("data");
        assertNotNull(analysis.get("studentAnalysis"));
        assertNotNull(analysis.get("basicAnalysis"));
        assertNull(analysis.get("courseAnalysis"));
    }
}