package com.example.mystuent;
import com.example.mystuent.controller.ScoreController;
import com.example.mystuent.entity.Score;
import com.example.mystuent.mapper.ScoreMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class ScoreControllerTestAI {

    @Mock
    private ScoreMapper scoreMapper;

    @InjectMocks
    private ScoreController scoreController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ================ 基础测试用例（人工设计） ================
    @Test
    void getScoreList_Success() {
        // 准备测试数据
        List<Score> mockScores = Arrays.asList(
                new Score(1, 1001, "Math", 90.5, "Spring", 3),
                new Score(2, 1002, "English", 85.0, "Spring", 2)
        );

        when(scoreMapper.getAllWithPage(0, 10)).thenReturn(mockScores);
        when(scoreMapper.countAll()).thenReturn(2);

        Map<String, Object> params = new HashMap<>();
        params.put("pageNum", 1);
        params.put("pageSize", 10);

        ResponseEntity<?> response = scoreController.getScoreList(params);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(((Map<?, ?>) response.getBody()).get("success").equals(true));
        assertEquals(2, ((List<?>) ((Map<?, ?>) response.getBody()).get("data")).size());
    }

    @Test
    void addScore_InvalidInput() {
        Score invalidScore = new Score(0, 0, "", 90.5, "", 0);
        ResponseEntity<?> response = scoreController.addScore(invalidScore);
        assertEquals(400, response.getStatusCodeValue());
    }

    // ================ AI生成增强测试用例 ================

    // 用例1: 并发添加成绩测试
    @Test
    void addScore_ConcurrentExecution() throws InterruptedException {
        int threadCount = 5;
        CountDownLatch latch = new CountDownLatch(threadCount);

        when(scoreMapper.addScore(any())).thenReturn(1);

        for (int i = 0; i < threadCount; i++) {
            int finalI = i;
            new Thread(() -> {
                Score score = new Score(10 + finalI, 1001, "Concurrent", 80.0, "Fall", 2);
                scoreController.addScore(score);
                latch.countDown();
            }).start();
        }

        assertTrue(latch.await(3, TimeUnit.SECONDS));
        verify(scoreMapper, times(threadCount)).addScore(any());
    }

    // 用例2: 非法分数边界测试
    @Test
    void addScore_InvalidScoreValues() {
        // 测试分数超过100
        Score overScore = new Score(1, 1001, "Math", 101.0, "Spring", 3);
        ResponseEntity<?> response1 = scoreController.addScore(overScore);
        assertFalse(((Map<?, ?>) response1.getBody()).get("success").equals(true));

        // 测试负分数
        Score negativeScore = new Score(2, 1001, "Math", -1.0, "Spring", 3);
        ResponseEntity<?> response2 = scoreController.addScore(negativeScore);
        assertFalse(((Map<?, ?>) response2.getBody()).get("success").equals(true));
    }

    // 用例3: 超大分页参数测试
    @Test
    void getScoreList_ExtremePageSize() {
        Map<String, Object> params = new HashMap<>();
        params.put("pageNum", 1);
        params.put("pageSize", 10000); // 超出合理范围

        // 假设Mapper会抛出异常
        when(scoreMapper.getAllWithPage(0, 10000)).thenThrow(new RuntimeException());

        ResponseEntity<?> response = scoreController.getScoreList(params);
        assertEquals(500, response.getStatusCodeValue());
    }

    // 用例4: 事务一致性测试
    @Test
    void updateScore_TransactionRollback() {
        Score score = new Score(1, 1001, "Math", 90.0, "Spring", 3);

        // 模拟第一次更新成功，第二次失败
        when(scoreMapper.updateScore(score))
                .thenReturn(1)
                .thenThrow(new RuntimeException("DB Error"));

        // 第一次更新应该成功
        ResponseEntity<?> response1 = scoreController.updateScore(score);
        assertTrue(((Map<?, ?>) response1.getBody()).get("success").equals(true));

        // 第二次更新应触发事务回滚
        ResponseEntity<?> response2 = scoreController.updateScore(score);
        assertEquals(500, response2.getStatusCodeValue());
    }

    // 用例5: 混合条件搜索测试
    @Test
    void searchScores_ComplexConditions() {
        // 模拟复杂查询结果
        List<Score> mockResults = Collections.singletonList(
                new Score(1, 1001, "Advanced Math", 95.0, "Fall", 4)
        );

        when(scoreMapper.searchScores(1001, null, "Math", "Fall", 90.0, 100.0, 0, 10))
                .thenReturn(mockResults);
        when(scoreMapper.countSearchResults(1001, null, "Math", "Fall", 90.0, 100.0))
                .thenReturn(1);

        Map<String, Object> params = new HashMap<>();
        params.put("stuno", "1001");
        params.put("courseName", "Math");
        params.put("semester", "Fall");
        params.put("minScore", "90");
        params.put("maxScore", "100");
        params.put("pageNum", 1);
        params.put("pageSize", 10);

        ResponseEntity<?> response = scoreController.searchScores(params);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, ((List<?>) ((Map<?, ?>) response.getBody()).get("data")).size());
    }
}